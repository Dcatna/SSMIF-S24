run `npm i` to install all of the dependencies
run `npm run dev` to start up a development server

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.
- [`next/font`](https://nextjs.org/docs/pages/building-your-application/optimizing) - automatically optimize and load assets